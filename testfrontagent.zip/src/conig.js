const config = {
  basename:"",
  defaultPath:"/",
  fontFamily:'sans-serif',
  API_SERVER :"http://bboxxvm/"
}
export default config